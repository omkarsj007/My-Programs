// HW6-CS1337-Omkar-Jagdale
// This program is an implementation of binary trees. This is an animal guessing game. With every guess made by the algorithm and
// every question supplied by the user, the algorithm learns and eventually becomes capable of guessing better.
// the nodes in this program are dynamically created


#include <iostream> // to use the cout and cin objects
#include <climits> // to use INT_MAX

using namespace std;

struct animalNode // create a structure called animal node
{
    string guess; // stores the guess
    string question; // stores the question to be asked
    animalNode * yesAnswer; // points to the next animal node if answer is yes
    animalNode * noAnswer; // points to the next animal node if answer is no
};

animalNode * makeNewLeafNode(string word) // this function creates and returns a node of the structure animalNode
{
    animalNode * newNode; // new node declared
    newNode = new animalNode; // memory dynamically allocated
    newNode -> guess = word; // the word is stored in the guess member
    newNode -> question = ""; // the question member is set to empty
    newNode -> yesAnswer = nullptr; // the two pointers point to nothing
    newNode -> noAnswer = nullptr;
    return newNode; // return the newly defines animal Node
}

bool b = true; // is the flag that determines whether the game will proceed



void play(animalNode * curNode) // this function plays the game
{

   if(curNode -> yesAnswer == nullptr && curNode -> noAnswer == nullptr) // checks if the node is a leaf node
   {
       string answer;
       cout << "Is your animal " << curNode -> guess << endl;
       cin >> answer; // accepts from the user whether the answer is yes/no
       if(answer == "no")
       {
             string animalName;
            string questionAboutAnimal;
            string choice;
            cout << "What is the animal you are thinking about" << endl;
            cin >> animalName;
            cin.ignore(INT_MAX, '\n'); // ignores any excess characters in the buffer
            cout << "Give me a question to differentiate between them" << endl;
            getline(cin, questionAboutAnimal);
            cout << "Is the answer to the question yes or no for your animal" << endl;
            cin >> choice;
            if(choice == "yes")
            {
                string temp = curNode -> guess;
                curNode -> guess = ""; // the guess member is reset
                curNode -> question = questionAboutAnimal; // the leaf node becomes a question node
                curNode -> yesAnswer = makeNewLeafNode(animalName); // the yesAnswer points to a leaf node with answer animalName
                curNode -> noAnswer = makeNewLeafNode(temp); // the noAnswer points to a leaf node with answer guess

            }
            else if(choice == "no")
            {
                string temp = curNode -> guess;
                curNode -> guess = "";// the guess member is reset
                curNode -> question = questionAboutAnimal;// the leaf node becomes a question node
                curNode -> noAnswer = makeNewLeafNode(animalName);// the noAnswer points to a leaf node with answer animalName
                curNode -> yesAnswer = makeNewLeafNode(temp);// the yesAnswer points to a leaf node with answer guess

            }



       }
       if(answer == "yes") // is executed if animal is found
       {
           cout << "YAAY. I guessed it." << endl;
           cout << "Game over" << endl;
           cout << endl;
       }

    }
    else // is executed if an internal node is encountered
    {
        string answer;
        cout << curNode -> question << endl; // the question is printed
        cin >> answer;
        if(answer == "yes")
        {
            play(curNode -> yesAnswer); // the function is called again(recursion), this time with the next node(yesAnswer points to this node)
        }
        else
        {
            play(curNode -> noAnswer); // the function is called again(recursion), this time with the next node(noAnswer points to this node)
        }
    }



}


 animalNode * root; // stores the root of the tree
 animalNode * curNode = nullptr; // stores the current node

int main()
{
    cout<<"Press enter when you are ready to play the game";
    char a;
    //cin.ignore(INT_MAX, '\n'); // ignores any non '\n' characters
    cin.get(a);// gets a character from the keyboard;
    while(a != '\n')
    {
        cin.get(a);
    }

    curNode = new animalNode; // dynamically creates a new animal node
    curNode -> question = ""; // sets the question to empty
    curNode -> guess = "lizard"; // sets the guess to lizard
    curNode -> yesAnswer = nullptr; // sets the leaf pointer to nullptr
    curNode -> noAnswer = nullptr; // sets the second leaf pointer to nullptr

    root = curNode; // root stores the starting point of curNode
    while(b) // as long as the flag is true
    {
         play(root); // the root is passed to the play function
         cout << "Do you want to play again" << endl;
       string a;
       cin >> a;
       if(a == "no")
       {
           b = false;
       }


    }

    return 0;
}
