 // HW5-CS 1337-Omkar-Jagdale
// Game of Life
// This program is the simulation of the Game of life
// It gives the user two options to start the program
// A. Accept the first generation from a text file by supplying the filename
// OR
// B. Let the computer randomly generate the first generation. The user will have to specify the percentage of cells that should
//    be alive when the game starts
// The game has buttons 'p' and 's'. Pressing p will pause the game. Pressing any other key will resume the game
// Pressing 's' will copy the current state of the generation to a text file and quit the program.
// The program also validates the input provided by the user and the gives the user multiple chances to get the correct input



#include <iostream> // to use the cout and cin objects
#include <conio.h> // to use the _kbhit() and _getch()
#include <fstream> // to use the ifstream and ofstream objects
#include <cstdlib> // to the rand() and srand()
#include <ctime> // to use the time()
#include <vector> // to use vectors
#include <limits> // to use INT_MAX
#include <string> // to use strings

using namespace std;

const int maxRow = 50; // maximum rows and columns set to 50
const int maxColumn = 50;


void printit(int array1 [][maxColumn]) // to display gen1
{
    for(int i = 0; i < maxRow; i++)
        {
            for(int j = 0; j < maxColumn; j++)
            {
                if(array1[i][j] == 0) // if cell is dead then '.' is printed
                {
                    cout << ".";
                }
                else
                {
                    cout << "O"; // printed if the cell is alive
                }
            }
            cout << endl;
        }
}

void gameoflife(int gen1[][maxColumn], int gen2[][maxColumn])
{

    int xDir[] = {-1, -1, -1, 0, 0, 1, 1, 1}; // is added to the row index
    int yDir[] = {-1, 0, 1, -1, 1, -1, 0, 1}; // is added to the column index

    for(int i = 0; i < maxRow-1; i++) // to iterate through each row
        {
            for(int j = 0; j < maxColumn-1; j++) // to iterate through each column
            {

                int aliveCells = 0;

                    for(int k = 0; k <= 7; k++) //checks in all 8 directions
                    {
                        aliveCells += gen1[i + xDir[k]][j + yDir[k]]; // if the cell is alive, 1 is added else 0 is added
                    }


                if(aliveCells < 2 && gen1[i][j] == 1) // if living neighbor cells are less than 2, cell dies in next gen
                {
                    gen2[i][j] = 0;
                }
                else if(aliveCells >= 4 && gen1[i][j] == 1) // if living neighbor cells are greater than or equal to 4, then cell dies in next gen
                {
                    gen2[i][j] = 0;
                }
                else if(aliveCells  == 3 && gen1[i][j] == 0) // if living neighbor cells are equal to 3, then cell becomes alive in next gen.
                {
                    gen2[i][j] = 1;
                }
                else
                {
                    gen2[i][j] = gen1[i][j];
                }

            }
        }
}

void copyGen(int gen1[][maxColumn], int gen2[][maxColumn]) // copies the values from the second gen into the first gen matrix
{
    for(int i = 0; i < maxRow; i++)
    {
        for(int j = 0; j< maxColumn; j++)
        {
            gen1[i][j] = gen2[i][j];
        }
    }
}




void writeFile(int array1[][maxColumn]) // outputs the current state of the matrix to a text file
{
    ofstream outfile; // create an output file stream object
    outfile.open("LifeGridFinal.txt"); // open a file to output to
    for(int i = 0; i < maxRow; i++)
        {
            for(int j = 0; j < maxColumn; j++)
            {
                if(array1[i][j] == 0)
                {
                    outfile << ".";
                }
                else
                {
                    outfile << "O";
                }
            }
            outfile << endl;
        }
        outfile.close(); // close the file after use
}

void genFromFile(int array1[][maxColumn], vector <string>& comments)
{
    ifstream infile; // create an input file stream object
    cout << "Enter the filename" << endl;
    string filename;
    cin.ignore(INT_MAX, '\n'); // to ignore any characters that remain in the buffer
    getline(cin, filename); // accept the file name
    if(filename == "quit" || filename == "exit") // if the user does not have a valid filename or want to leave the program then they can quit
        {
            exit(0);
        }

    infile.open(filename); // open the file with the filename

    while(!infile) // executes only if the file could not be opened and continues as long as a valid name is not entered.
    {
        cout << "File \"" << filename << "\" could not be opened as it does not exist" << endl;
        cout << "Enter a valid filename" << endl;
        getline(cin, filename);
        if(filename == "quit" || filename == "exit") // if the user does not have a valid filename or want to leave the program then they can quit
        {
            exit(0);
        }
        infile.open(filename); // try to open the file again with the new file name
    }


    string c;
    getline(infile, c);
    while(c.at(0) == '#') // executes as long as the line starts with a #
    {
        comments.push_back(c); // comment pushed back
        getline(infile, c); // accept the next line
    }

    for(int i = 0; i < maxRow; i++)
    {
       string s;
       getline(infile, s); // accepts the whole line into a string
       int x = s.length();
       for(int j = 0; j < x; j++) // checks assigns the corresponding values for the characters in the array
       {
           if(s.at(j) == '.')
           {
               array1[i][j] = 0;
           }
           if(s.at(j) == 'O')
           {
               array1[i][j] = 1;
           }
       }
       for(int a = x; a < maxColumn; a++) // if the line supplied does not have sufficient columns then the remaining elements in the row are set to 0
       {
           array1[i][a] = 0;
       }
    }
    infile.close(); // file is closed after use
}

void genByPercentage(int array1[][maxColumn])
{
     cout << "Enter the percentage for living cells." << endl;
        int cells;
        cin >> cells;

        while(cells <= 0 || cells > 100) // to check whether a valid percentage value has been entered
        {
            cout << "Enter a percentage value between 0 and 100 " << endl;
            cin >> cells;
        }

        srand(time(0)); // srand() seeded with the time()
        cells = (maxRow*maxColumn*cells)/100; // number of cells to set alive calculated

        for(int i = 0; i < cells; i++)
        {
            int indexX = rand() % maxRow; // random position assigned as x coordinate
            int indexY = rand() % maxColumn; // random position assigned as y coordinate
            if(array1[indexX][indexY] == 0) // checks whether the cell at the index position is dead
            {
                array1[indexX][indexY] = 1; // makes it alive
            }
            else // the else block is executed when the random position generated points to a cell that is already alive;
            {
                i--; // in such a case the loop is given one more iteration so that another position can be found
            }
        }
}

void printCommments(vector <string> statements) // this function prints the comments that were obtained from the file before reading the pattern
{
    int statementSize = statements.size();
    for(int i = 0; i < statementSize; i++)
    {
        cout << statements[i] << endl;
    }
}

int gen1 [maxRow][maxColumn];

int main()
{

        cout << "Choice A : Accept a pattern from a file for first generation" << endl;
        cout << "Choice B : Let the computer randomly generate a pattern for the first generation" << endl;

        cout << "Choose A or B" << endl;
        char choice;
        cin >> choice;
        vector <string> comments; // stores the comments

        while(choice != 'A' && choice != 'a' && choice != 'B' && choice != 'b' ) // checks whether the user enters a valid choice
        {
            cout << "Please choose A or B" << endl;
            cin.ignore(INT_MAX, '\n'); // clears the buffer of any residual characters
            cin >> choice; // accepts the choice again
        }
        if(choice == 'A' || choice == 'a')
        {
            genFromFile(gen1, comments); // called for choice a
        }
        if(choice == 'B' || choice == 'b')
        {
            genByPercentage(gen1); // called for choice b
        }




        bool gameOver = false; // terminating factor for the loop
        bool pause = false; // used to pause the game
        while(!gameOver)
        {
            //printit(gen1);
            if(!pause) // as long as pause is false the block of code is executed
            {
                cout << endl;
                int gen2 [maxRow][maxColumn]; // stores the future gen
                gameoflife(gen1, gen2); // game of life is the logic of the game
                system("CLS"); // the screen is cleared
                printCommments(comments);// the comments are printed
                printit(gen1); // the generation is printed
                copyGen(gen1, gen2); // the future generation is copied into the present generation array
            }


            if(_kbhit()) // checks if the keyboard has been hit
            {
                char c =  _getch(); // gets the character hit on the keyboard and stores it in c
                if(c == 's')
                {
                    writeFile(gen1); // the current state of the gen is written to a text file
                    gameOver = true; // the game is quit
                }
                else if(c == 'p')
                {
                    pause = true; // to pause the game
                }
                else
                {
                    pause = false; // any other key will have no effect if the game is playing and it will resume the game if it was paused
                }
            }
        }

    return 0;
}
