// This program is a Snake Game
// The program uses WASD keys to control the directions of the snake
// in the game
// Bug has been fixed
// The game also has keys the Q and X to quit the game and the Key P
// pauses the game. To resume the game, any other key can be pressed. However, the
// WASD keys are disabled when paused. Pressing any other key will resume the game
// The instructions are displayed before the start of the game
// The user has a the option to provide the number of fruits they would like
// to be present in the game. The game can have a maximum of 5 fruits
// The user is also provided with two lives. The lives will be indicated
// below the score


#include <string>
#include <iostream>
#include <conio.h> // for _kbhit and _getch in the input routine
#include <windows.h> // for the sleep function in main
//#include <ctime> // for the time function
using namespace std;

bool gameOver; // true when the game is over and we should quit
const int width = 20; // height of board
const int height = 20; // width of board
int headX, headY; // location of the snake's head -- very bad global names!!
int fruitX[5], fruitY[5]; // location of the fruit
int score; // stores the score
int numberOfFruits; // stores the number of fruits
int tailX[100], tailY[100]; // positions of all tail elements
int nTail; // length of tail
int lives = 2; // stores the number of lives
enum eDirection { STOPPED = 0, LEFT, RIGHT, UP, DOWN}; // directions snake can travel
eDirection dir; // direction snake is traveling
eDirection dir1; // stores the temporary direction
bool pause = false; // the control variable used to pause the game

int sleepAmt = 100;

void instructions()
{
    cout << "Welcome to the Snake Game "<< endl;
    cout << "--------------------------"<< endl;
    cout << "Use the keys: "<< endl;
    cout << "W to go UP" << endl;
    cout << "S to go DOWN" << endl;
    cout << "A to go LEFT" << endl;
    cout << "D to go RIGHT" << endl;
    cout << "P to pause the game" << endl;
    cout << "(press any key, other than the above controls to resume the game)" << endl;
    cout << "Q or X to terminate the game" << endl;
    cout << "You have 2 lives!!!" << endl;
    cout << "Stay away from your tail to stay in the game." << endl;
    cout << "All the best :)" << endl;
    cout << "--------------------------"<< endl;
}

void fruitNumber() // accepts the user's choice for number of fruits
{
    cout << "How many fruits would you like. You can have a max of 5 fruits." << endl;
    cin >> numberOfFruits;
	while(numberOfFruits > 5 || numberOfFruits <= 0) // to check whether the user enters the a number within range
    {
        cout << "You can have a max of 5 fruits. Enter a number from 1 to 5 " << endl;;
        cin >> numberOfFruits;
    }
    for(int fruits = 0; fruits < numberOfFruits; fruits++)
    {
        fruitX[fruits] = rand() % width; // spawn the fruits at the index position
        fruitY[fruits] = rand() % height;
    } // end for

} // end fruitNumber

void setup() {
	gameOver = false;
	dir = STOPPED; // start in paused (stopped) mode

	headX = width / 2; // set location of the snake's head to middle of game board
	headY = height / 2;

	//srand(time(0)); // seed the random number generator
	instructions(); // prints the instructions for the user
	fruitNumber(); // accepts the user's choice for number of fruits and creates that many fruits
	score = 0; // clear the user's score
} // setup


bool snakeHead(int row, int column) // checks whether the snake's head is to be printed for the provided index positions
{
    if(row == headY && headX == column)
    return true;
    else
    return false;
} // end snakeHead

bool fruitHead(int row, int column) // checks whether the fruits have to be printed for the given index positions
{
    for(int i = 0; i < numberOfFruits; i++)
    {
        if(fruitY[i] == row && fruitX[i] == column)
            return true;
    } // end for
    return false;
} // end fruitHead

bool tailPrint(int row, int column) // checks whether a part of the tail is printed at the index position
{
    bool Tail = false;
    for (int k = 0; k < nTail; k++)
    {
        if (tailX[k] == column && tailY[k] == row)
        {
            cout << "o"; // print part of the tail
            Tail = true;
        } // end if
    }// end for
    return Tail;
}// end tailPrint

void draw() {
	system("cls"); //clear the screen

	//draw the top wall
	for (int i = 0; i < width+2; i++)
		cout << "#";
	cout << endl;

	for (int i = 0; i < height; i++) { // draw each row
		for (int j = 0; j < width; j++) // print each column
            {
			if (j == 0) // print wall cell
                cout << "#";
			else if (snakeHead(i,j)) // print snake's head
                cout << "O";
			else if (fruitHead(i,j)) // print the fruit
				cout << "F";
			else
			{ // see if we're in part of the snake's tail
                    bool snakeTail = tailPrint(i,j); // tailPrint returns whether tail is at the cell or not
                    if (!snakeTail) cout << " "; // we're just at an empty cell
            } // end else

            //draw the far wall if at the end
			if (j == width - 1)
				cout << "#";
		} // end for j
		cout << endl; // we're through with this row
	} // end for i

    //draw the bottom wall
	for (int i = 0; i < width+2; i++)
		cout << "#";
	cout << endl;

	//show the player's score below the game grid
	cout << "Score:" << score << endl;

	if(lives == 2) // if the player has two lives
    cout << "Lives:" << lives  << endl;
    else if(lives == 1) // if the player has his final life remaining
    cout << "Last Life" <<endl;

} // end draw



void input() {

    if (_kbhit()) { // check if the keyboard has been hit
		switch (_getch()) { // it has, so get the key that was typed
            case 'a':
                dir = LEFT;
                break;
            case 'd':
                dir = RIGHT;
                break;
            case 'w':
                dir = UP;
                break;
            case 's':
                dir = DOWN;
                break;
            case 'q':
            case 'x':
                gameOver = true;
                break;
            case '+':
                sleepAmt += 20;
                cout<<"Increasing sleepAmt to " << sleepAmt << endl;
                break;
            case '-':
                if (sleepAmt > 20) {
                    sleepAmt -= 20;
                    cout << "Decreasing sleepAmt to" << sleepAmt << endl;
                }
                break;
            case 'p':
            dir1 = dir; // store the original direction in the dir1 variable
            dir = STOPPED;
            pause = true; // the pause variable is responsible for stopping the logic function of the program
            // making dir = stopped only stops the head. In order to stop the tail from moving, the logic function is paused
            break;
            default:
               {
                    dir = dir1; // reassign the original direction to dir
                    pause = false;
               }
		} // end switch
	} // end if
} // end input


void changeSnakeDirection()
{
    switch (dir) {
        case LEFT:
            headX--;
            break;
        case RIGHT:
            headX++;
            break;
        case UP:
            headY--;
            break;
        case DOWN:
            headY++;
            break;
        default:
            break;
	} // end switch

    // Snake on touching a vertical wall emerges from the opposite vertical wall, in the same direction
	if (headX > width - 1) headX = 0; else if (headX < 1) headX = width -1;
	// Snake on touching a horizontal wall emerges from the opposite horizontal wall, in the same direction
	if (headY >= height) headY = 0; else if (headY < 0) headY = height -1;

} // end changeSnakeDirection

void game()
{
    cout << "Do you want to play another game? (Y / N) " << endl;
    bool flag = false;
    string s = "";
    while(!flag)
    {
        cin >> s; // accepts everything entered by the user
        char a = s.at(0); // extracts the first character of string
        if(a == 'Y'|| a == 'y') // check if yes
        {
            gameOver = false; // to make sure the game does not end
            fruitNumber(); // to give the user the option to choose a new number of fruits
            score = 0; // reset the game parameters
            nTail = 0;
            lives = 2;
            dir = STOPPED; // start in paused (stopped) mode

            headX = width / 2; // set location of the snake's head to middle of game board
            headY = height / 2;
            flag = true;// to exit the loop
        }// end if

        else if(a == 'N' || a == 'n')
        {
            gameOver = true;
            flag = true; // to exit the loop
        }// end else if
        else
        {
           flag = false; // to exit the loop
        }
    } // end while

} // end game

void checkEndGame()
{
    for (int i = 0; i < nTail; i++) {
		if (tailX[i] == headX && tailY[i] == headY) {
			//gameOver = true;
			lives--;
			cout << "You hit your own tail!" << endl;
			if(lives == 0) // to check if all lives are lost
			{
			    cout << "You lost all lives" << endl;
                game();
			}

        } // end if
    }// end for
} // end checkEndGame


void checkFruitEaten()
{
    for(int i = 0; i < numberOfFruits; i++)
    {
	if (headX == fruitX[i] && headY == fruitY[i]) {
        // yes, we have, so increase the score
		score += 10;
        // and spawn a new fruit
		fruitX[i] = rand() % width;
		fruitY[i] = rand() % height;
		nTail++;
	} //end if
    } // end for

} // end checkFruitEaten

void logic() {
	int firstX = tailX[0]; // first index of tail stored in the first position
	int firstY = tailY[0];
	int nextX, nextY;
	tailX[0] = headX; // the current head position becomes the head of the tail
	tailY[0] = headY;
	for (int i = 1; i < nTail; i++)
    {
        // the next index becomes the part of tail next in line
		nextX = tailX[i];
		nextY = tailY[i];
		// the part of the tail is replaced with the first index of the tail
		tailX[i] = firstX;
		tailY[i] = firstY;
		// the first index becomes the part of the tail next in line
		firstX = nextX;
		firstY = nextY;
	}
    // functionalities spread out across other functions
	changeSnakeDirection();
	checkFruitEaten();
    checkEndGame();


} // logic



int main() {

	setup();

	while (!gameOver) {
		draw();
		input();
		if(!pause) // checks if the program has been paused
        {
            logic(); // if the program has not been paused, the logic of moving the snake is executed
        }
		//Sleep(sleepAmt); // slow the redraws down
	} // while

    return 0; // no longer needed
} // end main

